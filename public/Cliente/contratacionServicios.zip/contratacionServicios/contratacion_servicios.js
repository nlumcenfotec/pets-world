var swiper = new Swiper(".swiper-container", {
  speed: 1500,
  loop: true,
  // autoplay: {
  //     delay: 500
  // },
  plugins: [SwiperPluginAutoPlay]
});